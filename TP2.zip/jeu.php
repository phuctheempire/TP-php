<?php

class Jeu
{
    private $aDeviner = 30;
    private $actuel = null;
    private $message = -1;
    private $value = null;
    private $alcoolemie = 0;


    public function __construct()
    {
    }

    public function deviner($chiffre = null)
    {
        if (isset($chiffre)) {
            $tries = Session::get("usertries");
            $tries = $tries + 1;
            Session::set("usertries", $tries);

            $numberToGuess = $this->getNumberToGuess();
            $this->actuel = $numberToGuess;
            $this->value = (int) $_GET['chiffre'];

            if ($this->bernoulli_distribution($this->alcoolemie)) {
                if ($this->value > $numberToGuess) {
                    $this->message = 1;
                } elseif ($this->value < $numberToGuess) {
                    $this->message = 2;
                } else {
                    $this->message = 0;
                }

                if ($this->alcoolemie <= 0.9) {
                    $this->alcoolemie += 0.1;
                } else {
                    $this->alcoolemie = 1;
                }
                ;
            } else {
                if ($this->value > $numberToGuess) {
                    $this->message = 2;
                } elseif ($this->value < $numberToGuess) {
                    $this->message = 1;
                } else {
                    $this->message = 0;
                }

            }
            $_SESSION['drunk'] = $this->alcoolemie;
            $this->value = $_GET['chiffre'];

        }
    }

    public function bernoulli_distribution($taux)
    {
        $number = rand(0, 99);
        if ($number <= 100 - $taux * 100) {
            return true;
        } else {
            return false;
        }
    }

    public function getMessage()
    {
        return $this->message;
    }
    public function getValue()
    {
        return $this->value;
    }

    public function getNombreADeviner()
    {
        return $this->actuel;
    }
    private function getNumberToGuess()
    {
        // Check option random
        if (isset($_GET['games']) && in_array('first', $_GET['games'])) {
            // 'first' or 'second' or 'third
            $_SESSION['random_number'] = null;
            $_SESSION['prev_mode'] = 'first';
            return $this->aDeviner;
        } elseif (isset($_GET['games']) && in_array('second', $_GET['games'])) {
            // 'first' or 'second' or 'third
            if ($_SESSION['prev_mode'] == 'second') {
            } else {
                $_SESSION['random_number'] = rand(1, 100);
            }
            $_SESSION['prev_mode'] = 'second';
            return $_SESSION['random_number'];
        } elseif (isset($_GET['games']) && in_array('third', $_GET['games'])) {
            $this->alcoolemie = $_SESSION['drunk'];
            if ($_SESSION['prev_mode'] == 'third') {
            } else {
                $_SESSION['random_number'] = rand(1, 100);
            }
            $_SESSION['prev_mode'] = 'third';
            return $_SESSION['random_number'];
        } else {
            $_SESSION['random_number'] = null;
            return $this->aDeviner;
        }
    }
}