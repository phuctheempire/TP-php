<div class="content">
    <h2 class="content-title">Recent Articles</h2>
    <hr>
    <?php include(ROOT_PATH . '/includes/all_functions.php');
		$posts = getPublishedPosts(); 
		foreach( $posts as $post){ ?>
		<div class="post" style="margin-left: 0px;">
            <p class='category'><?php echo $post["topic"]["name"] ?></p>
			<img src="static/images/<?php echo $post["image"]  ?>" class="post_image" alt="">
			<h3><?php echo $post["title"] ?></h3>
			<div class='post_info'>
			<p>Updated: <?php echo $post["created_at"] ?> </p>
			<span class='read_more'><a href="single_post.php?post-slug=<?php echo $post['slug']; ?>">Read more...</a></span>
			</div>
		</div>
	<?php } ?>
</div>