<?php
$admin_id = 0;
$isEditingUser = false;
$username = "";
$email = "";

$topic_id = 0;
$isEditingTopic = false;
$topic_name = "";

$errors = [];

if (isset($_POST['create_admin'])) {
    createAdmin($_POST);
}

if (isset($_POST['update_admin'])) {
    updateAdmin($_POST);
}

if (isset($_GET['edit-admin'])) {
    editAdmin($_GET['edit-admin']);
}

function getAdminRoles(){
    global $conn;
    $sql = "SELECT * FROM roles WHERE name='Admin' OR name='Author'";
    $result = mysqli_query($conn, $sql);
    $roles = mysqli_fetch_all($result, MYSQLI_ASSOC);
    return $roles;
}

function getAdminUsers(){
    global $conn;
    $sql = "SELECT * FROM users WHERE role='Admin' OR role='Author'";
    $result = mysqli_query($conn, $sql);
    $users = mysqli_fetch_all($result, MYSQLI_ASSOC);
    return $users;
}

function createAdmin($request_values){
    global $conn, $errors;

    $username = $request_values['username'];
    $email = $request_values['email'];
    $password = $request_values['password'];
    $passwordConfirm = $request_values['passwordConfirmation'];
    $role = $request_values['role_id'];

    if (empty($username)) { array_push($errors, "Username is required"); }
    if (empty($email)) { array_push($errors, "Email is required"); }
    if (empty($password)) { array_push($errors, "Password is required"); }
    if (empty($role)) { array_push($errors, "Role is required"); }
    if ($password != $passwordConfirm) { array_push($errors, "Passwords do not match"); }

    $sql = "SELECT * FROM users WHERE username='$username' OR email='$email' LIMIT 1";
    $result = mysqli_query($conn, $sql);
    $user = mysqli_fetch_assoc($result);

    if ($user) { 
        if ($user['username'] === $username) {
            array_push($errors, "Username already exists");
        }
        if ($user['email'] === $email) {
            array_push($errors, "Email already exists");
        }
    }

    if (empty($errors)){
        $sql = "SELECT name FROM roles WHERE id = $role";

        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($result);
        
        $role_name = $row['name'];

        $password = md5($password);
        $sql = "INSERT INTO users (username, email, password, role, created_at) VALUES ('$username', '$email', '$password', '$role_name', NOW())";

        if (mysqli_query($conn, $sql)) {
            $_SESSION['message'] = "Admin user created successfully";
            header('location: users.php');
            exit(0);
        } else {
            array_push($errors, "Failed to create admin user");
        }
    }
}

function editAdmin($adminId){
    global $conn, $username, $isEditingUser, $email, $admin_id;
    $admin_id = $adminId;
    $sql = "SELECT * FROM users WHERE id=$admin_id LIMIT 1";
    $result = mysqli_query($conn, $sql);
    $admin = mysqli_fetch_assoc($result);
    $username = $admin['username'];
    $email = $admin['email'];

    $isEditingUser = true;
}

function updateAdmin($request_values){
    global $conn, $errors;
    $username = $request_values['username'];
    $email = $request_values['email'];
    $password = $request_values['password'];
    $passwordConfirm = $request_values['passwordConfirmation'];
    $role = $request_values['role_id'];
    $admin_id = $request_values['admin_id'];

    if (empty($username)) { array_push($errors, "Username is required"); }
    if (empty($email)) { array_push($errors, "Email is required"); }
    if (empty($password)) { array_push($errors, "Password is required"); }
    if (empty($role)) { array_push($errors, "Role is required"); }
    if ($password != $passwordConfirm) { array_push($errors, "Passwords do not match"); }


    if (empty($errors)){
        $sql = "SELECT name FROM roles WHERE id = $role";

        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($result);
            
        $role_name = $row['name'];
        $password = md5($password);

        $query = "UPDATE users SET username='$username', password='$password', role='$role_name' WHERE id=$admin_id";
        
        if (mysqli_query($conn, $query)) {
            $_SESSION['message'] = "Admin user updated successfully";
            header('location: users.php');
            exit(0);
        } else {
            array_push($errors, "Failed to update admin user");
        }
    }
}

function countUsers() {
    global $conn;
    $sql = "SELECT COUNT(*) FROM users";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($result, MYSQLI_NUM);
    return $row[0];
}

function countPosts() {
    global $conn;
    $sql = "SELECT COUNT(*) FROM posts";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($result, MYSQLI_NUM);
    return $row[0];
}